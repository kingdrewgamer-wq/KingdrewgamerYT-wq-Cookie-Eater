chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "incrementCount") {
    chrome.storage.local.get({ blockedCount: 0 }, (data) => {
      let newCount = data.blockedCount + request.amount;
      chrome.storage.local.set({ blockedCount: newCount });
    });
  }
});
