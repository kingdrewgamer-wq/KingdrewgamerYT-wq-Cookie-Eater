const bannerSelectors = [
  '#cookie-banner', '#consent-banner', '.cookie-notice', 
  '.gdpr-banner', '[aria-label*="cookie" i]', '[id*="cookie" i]', '[class*="cookie" i]'
];

function removeCookieBanners() {
  let blockedThisRun = 0;
  bannerSelectors.forEach(selector => {
    document.querySelectorAll(selector.toLowerCase()).forEach(element => {
      if (element.style.display !== 'none') {
        element.style.display = 'none';
        blockedThisRun++;
      }
    });
  });

  // If we hid any banners, tell the background script to add them to the count
  if (blockedThisRun > 0) {
    chrome.runtime.sendMessage({ action: "incrementCount", amount: blockedThisRun });
  }
}

removeCookieBanners();

const observer = new MutationObserver(() => {
  removeCookieBanners();
});
observer.observe(document.body, { childList: true, subtree: true });
