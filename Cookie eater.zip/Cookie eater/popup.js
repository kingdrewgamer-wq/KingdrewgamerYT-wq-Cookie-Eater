chrome.storage.local.get({ blockedCount: 0 }, (data) => {
  document.getElementById('count').textContent = data.blockedCount;
});
